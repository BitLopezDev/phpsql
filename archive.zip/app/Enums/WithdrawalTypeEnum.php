<?php

namespace App\Enums;

enum WithdrawalTypeEnum: int {

    case Withdrawal = 1;
    case Purchase = 2;

}