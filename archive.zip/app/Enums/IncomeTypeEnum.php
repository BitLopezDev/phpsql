<?php

namespace App\Enums;

enum IncomeTypeEnum: int {

    case Salary = 1;
    case Refund = 2;

}